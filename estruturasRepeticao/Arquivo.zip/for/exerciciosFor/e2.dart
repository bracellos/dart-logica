void main(List<String> args) {
  for (int i = 0; i <= 20; i += 2) {
    print(i);
  }
}
