void main() {
  for (int i = 100; i >= 50; i--) {
    print(i);
  }
}
