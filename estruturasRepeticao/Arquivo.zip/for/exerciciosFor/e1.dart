void main(List<String> args) {
  for (int i = 0; i < 10; i++) {
    print(i);
  }
}
