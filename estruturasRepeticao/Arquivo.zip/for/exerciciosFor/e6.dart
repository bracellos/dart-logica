void main(List<String> args) {
  for (int i = 1; i <= 30; i += 3) {
    print(i);
  }
}
