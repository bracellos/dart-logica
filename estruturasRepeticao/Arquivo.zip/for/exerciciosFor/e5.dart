void main(List<String> args) {
  for (int i = 10; i >= 1; i--) {
    print(i);
  }
}
