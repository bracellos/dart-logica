void main(List<String> args) {
  int soma = 0;
  for (int i = 0; i <= 50; i++) {
    soma += i;
  }
  print(soma);
}
