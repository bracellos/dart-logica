void main() {
  int i = 1;
  while (i <= 30) {
    if (i % 2 != 0) {
      print(i);
    }
    i++;
  }
}
