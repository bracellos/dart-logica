void main() {
  for (int i = 5; i <= 100; i++) {
    if (i % 10 == 5) {
      print(i);
    }
  }
}
