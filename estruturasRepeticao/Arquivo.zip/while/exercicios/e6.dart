void main() {
  int produto = 1;
  
  for (int i = 1; i <= 10; i++) {
    produto *= i;
  }
  
  print('O produto de todos os números de 1 a 10 é $produto');
}
